package demomdb2;

import javax.ejb.EJBException;
import javax.ejb.MessageDrivenBean;
import javax.ejb.MessageDrivenContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;


public class MyMDB2 implements MessageDrivenBean, MessageListener{

	@Override
	public void ejbRemove() throws EJBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setMessageDrivenContext(MessageDrivenContext arg0) throws EJBException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onMessage(Message message) {
		try {
			System.out.println("MDB - EJB 2.1 : " + ((TextMessage) message).getText());
		} catch (JMSException e) {
			e.printStackTrace();
		}
	}

}
