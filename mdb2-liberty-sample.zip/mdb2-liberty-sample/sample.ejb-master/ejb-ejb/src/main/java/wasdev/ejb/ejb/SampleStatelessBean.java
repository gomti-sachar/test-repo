package wasdev.ejb.ejb;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import com.demopoc.ejb3.HelloWorld;

@Stateless
public class SampleStatelessBean {
	
//	@EJB(lookup="java:global/demopoc/HelloWorldBean!com.demopoc.ejb3.HelloWorld")
//    HelloWorld helloWorld;

    public String hello() {
       //return helloWorld.printHello() + "***** Welcome to the Demo POC";
    	return "   Hi I am the bean INSIDE the EAR !!!!!   ";
    }
}
