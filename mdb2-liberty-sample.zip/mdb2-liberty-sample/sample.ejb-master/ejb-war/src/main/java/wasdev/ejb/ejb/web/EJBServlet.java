package wasdev.ejb.ejb.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.ejb.EJB;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.demopoc.ejb3.HelloWorld;

import wasdev.ejb.ejb.SampleStatelessBean;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.naming.InitialContext;

/**
 * A servlet which injects a stateless EJB
 */
@WebServlet({ "/", "/ejbServlet" })
public class EJBServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

//	@EJB
//	SampleStatelessBean statelessBean;

//	@EJB(lookup = "java:global/demopoc/HelloWorldBean!com.demopoc.ejb3.HelloWorld")
//	HelloWorld helloWorld;

	
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
		PrintWriter writer = response.getWriter();

		// Call hello method on a stateless session bean
//		String message = statelessBean.hello();

//		String message2 = helloWorld.printHello();

//		writer.println(message);

//		writer.println(message2);
		
		String requestMessage = request.getParameter("textmsg");
		if(requestMessage == null)
			requestMessage = "Liberty Sample Message";
		writer.println("Sending messages ************** ");

		try {
			QueueConnectionFactory cf1 = (QueueConnectionFactory) new InitialContext()
					.lookup("java:comp/env/jms/libertyQCF");

			Queue queue = (Queue) new InitialContext().lookup("java:comp/env/jms/libertyQue");

			QueueConnection con = cf1.createQueueConnection();
			con.start();
			// create a queue sender
			QueueSession sessionSender = con.createQueueSession(false, javax.jms.Session.AUTO_ACKNOWLEDGE);

			QueueSender send = sessionSender.createSender(queue);		
					
			TextMessage msg = sessionSender.createTextMessage();
			msg.setStringProperty("COLOR", "BLUE");
			msg.setText(requestMessage);

			send.send(msg);
			writer.println("Message sent successfuly");

			if (con != null)
				con.close();

		} catch (Exception e) {
			writer.println(e.getMessage());
		}

	}

}
